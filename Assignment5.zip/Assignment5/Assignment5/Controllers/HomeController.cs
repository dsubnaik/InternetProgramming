﻿using Microsoft.AspNetCore.Mvc;
using Assignment5.Models;

namespace Assignment5.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var model = new MyModel
            {
                Name = "Derrick Subnaik",
                Age = 21,
                HomeTown = "St. Croix, USVI",
                CurrentCity = "Corpus Christi, TX"
            };

            return View(model);
        }

        public IActionResult Education()
        {
            var model = new MyModel
            {
                Name = "Derrick Subnaik",
                EducationArray = new string[] { "Calallen High School", "Texas A&M University at Corpus Christi" },
                Major= "Computer Science",
                HighSchoolGradYear=2022,
                CollegeGradYear=2026
            };

            return View(model);
        }

        public IActionResult Sports()
        {
            var model = new MyModel
            {
                Name = "Derrick Subnaik",
                SportsArray = new string[] { "Baseball", "Football", "Basketball" }
            };

            return View(model);
        }
    }
}
