﻿namespace Assignment5.Models
{
    public class MyModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string HomeTown { get; set; }

        public string CurrentCity { get; set; }

        public string[] SportsArray { get; set; }

        public string[] EducationArray { get; set; }

        public string Major { get; set; }

        public int HighSchoolGradYear { get; set; }

        public int CollegeGradYear { get; set; }


    }
}
